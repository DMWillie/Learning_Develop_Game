Attack of the Orcs
==================

Introduction
-------------
This is a command line fantasy war game!

Documentation
--------------
Documentation can be found at...

Example Usage
-------------
Here is an example to import the modules from this package.

.. code:: python

    from wargame.attackoftheorcs import AttackOfTheOrcs
    game = AttackOfTheOrcs()
    game.play()

LICENSE
-------
See LICENSE.txt file.


